export const environment = {
  production: true,
  apiBase: 'https://tec-cloudapp-api.azurewebsites.net/api/',
  apiGetUser: 'user/GetUsers',
  ambiente: 'prod'
};

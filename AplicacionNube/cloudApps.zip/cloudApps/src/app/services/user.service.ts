import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserDto } from '../models/user';
import { environment } from '../../environments/environment';


const apiBase = environment.apiBase;
const apiUser = environment.apiGetUser;
const env = environment.ambiente;

@Injectable({
  providedIn: 'root'
})
export class UserService {
  

  constructor(private http: HttpClient) { }

  getUsers(){
    console.log(env);
    
    return this.http.get<UserDto[]>(apiBase + apiUser);
  }
}

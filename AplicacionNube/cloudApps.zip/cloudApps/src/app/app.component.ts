import { Component } from '@angular/core';
import { UserDto } from './models/user';
import Swal from 'sweetalert2'
import { UserService } from './services/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'cloudApps';

  users: UserDto[] = [];
  titlePAge = 'Listado de usuarios';


  constructor(userService: UserService){
    userService.getUsers().subscribe(x => {
      console.log(x);
      
      this.users.push(...x);
    })
  
  }

  onClick(item: any){
    Swal.fire({
      title: 'Estas seguro de eliminar a ' + item.name,
      text: "Esta accion irreversible",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Eliminar'
    }).then((result) => {
      if (result.isConfirmed) {
        this.users = this.users.filter(x => x.id != item.id);
        Swal.fire(
          'Eliminado!',
          'El registro ha sido eliminado',
          'success'
        )
      }
    })
  }
}

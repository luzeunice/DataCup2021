export interface UserDto {
    id: number;
    name: string;
    lastName: string;
    age: number;
    campus: string;
}

﻿
namespace Tec.CloudApp.Commons.Model
{
    public class UserDto
    {
        public int Id { get; set; }
        public string  Name { get; set; }

        public string LastName { get; set; }

        public int  Age { get; set; }

        public string Campus { get; set; }

    }
}
